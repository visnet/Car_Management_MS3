﻿using dotnetapp.Data;
using dotnetapp.Models;
using dotnetapp.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace dotnetapp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MaterialController : ControllerBase
    {
        //private readonly ApplicationDbContext _context;
        private readonly MaterialService _materialService;
        public MaterialController(MaterialService materialService)
        {
            //  _context = context;
            _materialService = materialService;
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<Material>> GetMaterial(int id)
        {

            var material = await _materialService.GetMaterialById(id);

            if (material == null)
            {
                return NotFound();
            }
            return material;


        }
        [HttpGet("{courseId}")]
        public async Task<ActionResult<Material>> GetMaterialByCourseId(int courseId)
        {

            var material = await _materialService.GetMaterialByCourseId(courseId);

            if (material == null)
            {
                return NotFound();
            }
            return material;


        }

      

        [Authorize(Roles = "Educator")]

        [HttpPost]
        public async Task<ActionResult> AddMaterial([FromBody] Material material)
        {
            try
            {
                var success = await _materialService.AddMaterial(material);
                if (success)
                    return Ok(new { message = "Material added successfully" });
                else
                    return StatusCode(500, new { message = "Failed to add material" });
            }
            catch (Exception ex)
            {
                // Console.WriteLine("ex"+ex);
                return StatusCode(400, new { message = ex.Message });
            }
        }
        [Authorize(Roles = "Educator")]

        [HttpPut("{materialId}")]
        public async Task<ActionResult> UpdateMaterial(int materialId, [FromBody] Material material)
        {
            try
            {
                var success = await _materialService.UpdateMaterial(materialId, material);

                if (success)
                    return Ok(new { message = "Material updated successfully" });
                else
                    return NotFound(new { message = "Cannot find any material" });
            }
            catch (Exception ex)
            {
                return StatusCode(400, new { message = ex.Message });
            }
        }
        [Authorize(Roles = "Educator")]

        [HttpDelete("{materialId}")]
        public async Task<ActionResult> DeleteMaterial(int materialId)
        {
            try
            {
                var success = await _materialService.DeleteMaterial(materialId);

                if (success)
                    return Ok(new { message = "Material deleted successfully" });
                else
                    return NotFound(new { message = "Cannot find any material" });
            }
            catch (Exception ex)
            {
                return StatusCode(400, new { message = ex.Message });
            }
        }


    }
}
