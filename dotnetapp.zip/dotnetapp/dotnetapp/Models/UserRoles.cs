﻿namespace dotnetapp.Models
{
    public static class UserRoles
    {
        public const string Educator = "Educator";

        public const string Student = "Student";
    }
}
