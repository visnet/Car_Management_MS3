﻿using dotnetapp.Data;
using dotnetapp.Models;
using dotnetapp.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace dotnetapp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnrollmentController : ControllerBase
    {
        //private readonly ApplicationDbContext _context;
        private readonly EnrollmentService _enrollmentService;
        public EnrollmentController(EnrollmentService enrollmentService)
        {
            //  _context = context;
            _enrollmentService = enrollmentService;
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<Enrollment>> GetEnrollment(int id)
        {

            var enrollment = await _enrollmentService.GetEnrollmentById(id);

            if (enrollment == null)
            {
                return NotFound();
            }
            return enrollment;


        }
        [HttpGet("{userId}")]
        public async Task<ActionResult<Enrollment>> GetEnrollmentByUserId(int userId)
        {

            var enrollment = await _enrollmentService.GetEnrollmentByUserId(userId);

            if (enrollment == null)
            {
                return NotFound();
            }
            return enrollment;


        }
       


        [Authorize(Roles = "Educator")]

        [HttpPost]
        public async Task<ActionResult> AddEnrollment([FromBody] Enrollment enrollment)
        {
            try
            {
                var success = await _enrollmentService.AddEnrollment(enrollment);
                if (success)
                    return Ok(new { message = "Enrollment added successfully" });
                else
                    return StatusCode(500, new { message = "Failed to add enrollment" });
            }
            catch (Exception ex)
            {
                // Console.WriteLine("ex"+ex);
                return StatusCode(400, new { message = ex.Message });
            }
        }
        [Authorize(Roles = "Educator")]

        [HttpPut("{enrollmentId}")]
        public async Task<ActionResult> UpdateEnrollment(int enrollmentId, [FromBody] Enrollment enrollment)
        {
            try
            {
                var success = await _enrollmentService.UpdateEnrollment(enrollmentId, enrollment);

                if (success)
                    return Ok(new { message = "Enrollment updated successfully" });
                else
                    return NotFound(new { message = "Cannot find any enrollment" });
            }
            catch (Exception ex)
            {
                return StatusCode(400, new { message = ex.Message });
            }
        }
        [Authorize(Roles = "Educator")]

        [HttpDelete("{enrollmentId}")]
        public async Task<ActionResult> DeleteEnrollment(int enrollmentId)
        {
            try
            {
                var success = await _enrollmentService.DeleteEnrollment(enrollmentId);

                if (success)
                    return Ok(new { message = "Enrollment deleted successfully" });
                else
                    return NotFound(new { message = "Cannot find any enrollment" });
            }
            catch (Exception ex)
            {
                return StatusCode(400, new { message = ex.Message });
            }
        }


    }
}
