﻿using dotnetapp.Data;
using dotnetapp.Exceptions;
using dotnetapp.Models;
using Microsoft.EntityFrameworkCore;

namespace dotnetapp.Services
{
    public class CourseService
    {
        private readonly ApplicationDbContext _context;

        public CourseService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Course>> GetAllCourses()
        {
            return await _context.Courses.ToListAsync();
        }

        public async Task<Course> GetCourseById(int courseId)
        {
            return await _context.Courses.FirstOrDefaultAsync(l => l.CourseId == courseId);
        }

        public async Task<Course> GetCourseByUserId(int userId)
        {
            return await _context.Courses.FirstOrDefaultAsync(l => l.UserId == userId);
        }



        public async Task<bool> AddCourse(Course course)
        {

            if (_context.Courses.Any(l => l.Title== course.Title))
            {
                throw new CourseException("Course with the same title already exists");
            }
            _context.Courses.Add(course);
            await _context.SaveChangesAsync();
            return true;

        }

        public async Task<bool> UpdateCourse(int courseId, Course course)
        {

            var existingCourse = await _context.Courses.FirstOrDefaultAsync(l => l.CourseId == courseId);

            if (existingCourse == null)
                return false;
            if (_context.Courses.Any(l => l.Title == course.Title && l.CourseId != courseId))
            {
                throw new CourseException("Course with the same type already exists");
            }
            course.CourseId = courseId;
            _context.Entry(existingCourse).CurrentValues.SetValues(course);
            await _context.SaveChangesAsync();

            return true;

        }

        public async Task<bool> DeleteCourse(int courseId)
        {

            var course = await _context.Courses.FirstOrDefaultAsync(l => l.CourseId == courseId);
            if (course == null)
                return false;
            if (_context.Materials.Any(l => l.CourseId == course.CourseId))
            {
                throw new CourseException("Course cannot be deleted, it is referenced in Material");
            }

            _context.Courses.Remove(course);
            await _context.SaveChangesAsync();
            return true;

        }
    }
}
