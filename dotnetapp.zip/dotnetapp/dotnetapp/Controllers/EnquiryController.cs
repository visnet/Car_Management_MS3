﻿using dotnetapp.Data;
using dotnetapp.Models;
using dotnetapp.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace dotnetapp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnquiryController : ControllerBase
    {
        //private readonly ApplicationDbContext _context;
        private readonly EnquiryService _enquiryService;
        public EnquiryController(EnquiryService enquiryService)
        {
            //  _context = context;
            _enquiryService = enquiryService;
        }
        [HttpGet("{userId}")]
        public async Task<ActionResult<Enquiry>> GetEnquiryByUserId(int userId)
        {

            var enquiry = await _enquiryService.GetEnquiryByUserId(userId);

            if (enquiry == null)
            {
                return NotFound();
            }
            return enquiry;


        }
        [HttpGet("{courseId}")]
        public async Task<ActionResult<Enquiry>> GetEnquiryByCourseId(int courseId)
        {

            var enquiry = await _enquiryService.GetEnquiryByCourseId(courseId);

            if (enquiry == null)
            {
                return NotFound();
            }
            return enquiry;


        }
      


        [Authorize(Roles = "Educator")]

        [HttpPost]
        public async Task<ActionResult> AddEnquiry([FromBody] Enquiry enquiry)
        {
            try
            {
                var success = await _enquiryService.AddEnquiry(enquiry);
                if (success)
                    return Ok(new { message = "Enquiry added successfully" });
                else
                    return StatusCode(500, new { message = "Failed to add enquiry" });
            }
            catch (Exception ex)
            {
                // Console.WriteLine("ex"+ex);
                return StatusCode(400, new { message = ex.Message });
            }
        }
        [Authorize(Roles = "Educator")]

        [HttpPut("{enquiryId}")]
        public async Task<ActionResult> UpdateEnquiry(int enquiryId, [FromBody] Enquiry enquiry)
        {
            try
            {
                var success = await _enquiryService.UpdateEnquiry(enquiryId, enquiry);

                if (success)
                    return Ok(new { message = "Enquiry updated successfully" });
                else
                    return NotFound(new { message = "Cannot find any enquiry" });
            }
            catch (Exception ex)
            {
                return StatusCode(400, new { message = ex.Message });
            }
        }
        [Authorize(Roles = "Educator")]

        [HttpDelete("{enquiryId}")]
        public async Task<ActionResult> DeleteEnquiry(int enquiryId)
        {
            try
            {
                var success = await _enquiryService.DeleteEnquiry(enquiryId);

                if (success)
                    return Ok(new { message = "Enquiry deleted successfully" });
                else
                    return NotFound(new { message = "Cannot find any enquiry" });
            }
            catch (Exception ex)
            {
                return StatusCode(400, new { message = ex.Message });
            }
        }


    }
}
