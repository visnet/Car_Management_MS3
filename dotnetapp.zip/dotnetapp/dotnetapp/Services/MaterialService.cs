﻿using dotnetapp.Data;
using dotnetapp.Exceptions;
using dotnetapp.Models;
using Microsoft.EntityFrameworkCore;

namespace dotnetapp.Services
{
    public class MaterialService
    {
        private readonly ApplicationDbContext _context;

        public MaterialService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<bool> UpdateMaterial(int materialId, Material material)
        {

            var existingMaterial = await _context.Materials.FirstOrDefaultAsync(l => l.MaterialId == materialId);

            if (existingMaterial == null)
                return false;
            if (_context.Materials.Any(l => l.Title == material.Title && l.MaterialId != materialId))
            {
                throw new MaterialException("Material with the same title already exists");
            }
            material.MaterialId = materialId;
            _context.Entry(existingMaterial).CurrentValues.SetValues(material);
            await _context.SaveChangesAsync();

            return true;

        }

        public async Task<Material> GetMaterialByCourseId(int courseId)
        {
            return await _context.Materials.FirstOrDefaultAsync(l => l.CourseId == courseId);
        }
        public async Task<Material> GetMaterialById(int materialId)
        {
            return await _context.Materials.FirstOrDefaultAsync(l => l.MaterialId == materialId);
        }

        public async Task<bool> AddMaterial(Material material)
        {

            _context.Materials.Add(material);
            await _context.SaveChangesAsync();
            return true;

        }

        public async Task<bool> DeleteMaterial(int materialId)
        {
            try
            {
                var existingMaterial = await _context.Materials.FindAsync(materialId);

                if (existingMaterial == null)
                {
                    return false;
                }

                _context.Materials.Remove(existingMaterial);
                await _context.SaveChangesAsync();

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}