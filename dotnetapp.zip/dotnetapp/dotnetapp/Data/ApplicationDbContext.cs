﻿using dotnetapp.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace dotnetapp.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }
        public DbSet<Course> Courses { get; set; }
        public DbSet<Enquiry> Enquiries { get; set; }
        public DbSet<Feedback> Feedbacks { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Enrollment> Enrollments { get; set; }
        public DbSet<Material> Materials { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            //modelBuilder.Entity<Enrollment>()
            //    .HasOne(p => p.User)
            //    .WithMany(e => e.Enrollments)
            //    .HasForeignKey(p => p.UserId)
            //    .OnDelete(DeleteBehavior.NoAction);


            //modelBuilder.Entity<Enquiry>()
            //  .HasOne(p => p.User)
            //  .WithMany(e => e.Enquiries)
            //  .HasForeignKey(p => p.UserId)
            //    .OnDelete(DeleteBehavior.NoAction);
            //base.OnModelCreating(modelBuilder);
            //modelBuilder.Entity<Feedback>()
            //  .HasOne(p => p.User)
            //  .WithMany(e => e.Feedbacks)
            //  .HasForeignKey(p => p.UserId)
            //    .OnDelete(DeleteBehavior.NoAction);
            //modelBuilder.Entity<Course>()
            //  .HasOne(p => p.User)
            //  .WithMany(e => e.Courses)
            //  .HasForeignKey(p => p.UserId)
            //    .OnDelete(DeleteBehavior.NoAction);

            //modelBuilder.Entity<Enquiry>()
            // .HasOne(p => p.Course)
            // .WithMany(e => e.Enquiries)
            // .HasForeignKey(p => p.CourseId)
            //   .OnDelete(DeleteBehavior.NoAction);
            //base.OnModelCreating(modelBuilder);
            //modelBuilder.Entity<Enrollment>()
            //  .HasOne(p => p.Course)
            //  .WithMany(e => e.Enrollments)
            //  .HasForeignKey(p => p.CourseId)
            //    .OnDelete(DeleteBehavior.NoAction);
            //modelBuilder.Entity<Material>()
            //  .HasOne(p => p.Course)
            //  .WithMany(e => e.Materials)
            //  .HasForeignKey(p => p.CourseId)
            //    .OnDelete(DeleteBehavior.NoAction);


            base.OnModelCreating(modelBuilder);
        }
    }
}
