﻿namespace dotnetapp.Exceptions
{
    public class EnrollmentException:ApplicationException
    {
        public EnrollmentException(string message) : base(message)
        {
        }
    }
}
