﻿using dotnetapp.Data;
using dotnetapp.Models;
using dotnetapp.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace dotnetapp.Controllers
{
    [Authorize(Roles = "Educator")]
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        //private readonly ApplicationDbContext _context;
        private readonly CourseService _courseService;
        public CourseController(CourseService courseService)
        {
          //  _context = context;
            _courseService = courseService;
        }
        [HttpGet("{userId}")]
        public async Task<ActionResult<Course>> GetCourseByUserId(int userId)
        {        
              
                var course = await _courseService.GetCourseByUserId(userId);

                if (course == null)
                {
                    return NotFound();
                }
            return course;
                   
            
        }
        [HttpGet("{courseId}")]
        public async Task<ActionResult<Course>> GetCourseByCourseId(int courseId)
        {

            var course = await _courseService.GetCourseByUserId(courseId);

            if (course == null)
            {
                return NotFound();
            }
            return course;


        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Course>>> GetCourses()
        {
          
            var courses = await _courseService.GetAllCourses();
            return Ok(courses);
        }
        [Authorize(Roles = "Educator")]

        [HttpPost]
        public async Task<ActionResult> AddCourse(Course course)
        {
            try
            {
                var success = await _courseService.AddCourse(course);
                if (success)
                    return Ok(new { message = "Course added successfully" });
                else
                    return StatusCode(500, new { message = "Failed to add course" });
            }
            catch (Exception ex)
            {
                // Console.WriteLine("ex"+ex);
                return StatusCode(400, new { message = ex.Message });
            }
        }
        [Authorize(Roles = "Educator")]

        [HttpPut("{courseId}")]
        public async Task<ActionResult> UpdateCourse(int courseId, [FromBody] Course course)
        {
            try
            {
                var success = await _courseService.UpdateCourse(courseId, course);

                if (success)
                    return Ok(new { message = "Course updated successfully" });
                else
                    return NotFound(new { message = "Cannot find any course" });
            }
            catch (Exception ex)
            {
                return StatusCode(400, new { message = ex.Message });
            }
        }
        [Authorize(Roles = "Educator")]

        [HttpDelete("{courseId}")]
        public async Task<ActionResult> DeleteCourse(int courseId)
        {
            try
            {
                var success = await _courseService.DeleteCourse(courseId);

                if (success)
                    return Ok(new { message = "Course deleted successfully" });
                else
                    return NotFound(new { message = "Cannot find any course" });
            }
            catch (Exception ex)
            {
                return StatusCode(400, new { message = ex.Message });
            }
        }


    }
}
