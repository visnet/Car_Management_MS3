﻿using dotnetapp.Data;
using dotnetapp.Exceptions;
using dotnetapp.Models;
using Microsoft.EntityFrameworkCore;

namespace dotnetapp.Services
{
    public class EnrollmentService
    {
        private readonly ApplicationDbContext _context;

        public EnrollmentService(ApplicationDbContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Enrollment>> GetAllEnrollment()
        {
            return await _context.Enrollments.Include(r => r.User).ToListAsync();
        }

        public async Task<Enrollment> GetEnrollmentByUserId(int userId)
        {
            return await _context.Enrollments.FirstOrDefaultAsync(l => l.UserId == userId);
        }
      
        public async Task<Enrollment> GetEnrollmentById(int enrollId)
        {
            return await _context.Enrollments.FirstOrDefaultAsync(l => l.EnrollmentId == enrollId);
        }

        public async Task<bool> AddEnrollment(Enrollment enquiry)
        {

            _context.Enrollments.Add(enquiry);
            await _context.SaveChangesAsync();
            return true;

        }

        public async Task<bool> DeleteEnrollment(int enquiryId)
        {
            try
            {
                var existingEnrollment = await _context.Enrollments.FindAsync(enquiryId);

                if (existingEnrollment == null)
                {
                    return false;
                }

                _context.Enrollments.Remove(existingEnrollment);
                await _context.SaveChangesAsync();

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public async Task<bool> UpdateEnrollment(int enrollmentId, Enrollment enrollment)
        {

            var existingEnrollment = await _context.Enrollments.FirstOrDefaultAsync(l => l.EnrollmentId == enrollmentId);

            if (existingEnrollment == null)
                return false;
            if (_context.Enrollments.Any(l => l.EnrollmentDate== enrollment.EnrollmentDate && l.EnrollmentId != enrollmentId))
            {
                throw new EnrollmentException("Enrollment with the same title already exists");
            }
            enrollment.EnrollmentId = enrollmentId;
            _context.Entry(existingEnrollment).CurrentValues.SetValues(enrollment);
            await _context.SaveChangesAsync();

            return true;

        }
    }
}

