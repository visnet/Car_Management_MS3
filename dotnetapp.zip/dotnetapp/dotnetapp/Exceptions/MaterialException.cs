﻿namespace dotnetapp.Exceptions
{
    public class MaterialException:ApplicationException
    {
        public MaterialException(string message) : base(message) { }
    }
}
