﻿using dotnetapp.Data;
using dotnetapp.Exceptions;
using dotnetapp.Models;
using Microsoft.EntityFrameworkCore;

namespace dotnetapp.Services
{
    public class EnquiryService
    {
        private readonly ApplicationDbContext _context;

        public EnquiryService(ApplicationDbContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Enquiry>> GetAllEnquiries()
        {
            return await _context.Enquiries.Include(r => r.User).ToListAsync();
        }

        public async Task<Enquiry> GetEnquiryByUserId(int userId)
        {
            return await _context.Enquiries.FirstOrDefaultAsync(l => l.UserId == userId);
        }
        public async Task<Enquiry> GetEnquiryByCourseId(int courseId)
        {
            return await _context.Enquiries.FirstOrDefaultAsync(l => l.CourseId == courseId);
        }
        public async Task<Enquiry> GetEnquiryById(int enquiryId)
        {
            return await _context.Enquiries.FirstOrDefaultAsync(l => l.EnquiryId == enquiryId);
        }

        public async Task<bool> AddEnquiry(Enquiry enquiry)
        {

            _context.Enquiries.Add(enquiry);
            await _context.SaveChangesAsync();
            return true;

        }

        public async Task<bool> DeleteEnquiry(int enquiryId)
        {
            try
            {
                var existingEnquiry = await _context.Enquiries.FindAsync(enquiryId);

                if (existingEnquiry == null)
                {
                    return false;
                }

                _context.Enquiries.Remove(existingEnquiry);
                await _context.SaveChangesAsync();

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public async Task<bool> UpdateEnquiry(int enquiryId, Enquiry enquiry)
        {

            var existingEnquiry = await _context.Enquiries.FirstOrDefaultAsync(l => l.EnquiryId == enquiryId);

            if (existingEnquiry == null)
                return false;
            if (_context.Enquiries.Any(l => l.EnquiryDate == enquiry.EnquiryDate && l.EnquiryId != enquiryId))
            {
                throw new CourseException("Enquiry with same date already exists");
            }
            enquiry.EnquiryId = enquiryId;
            _context.Entry(existingEnquiry).CurrentValues.SetValues(enquiry);
            await _context.SaveChangesAsync();

            return true;

        }
    }
}

