﻿using dotnetapp.Data;
using dotnetapp.Models;
using dotnetapp.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace dotnetapp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FeedbackController : ControllerBase
    {
        //private readonly ApplicationDbContext _context;
        private readonly FeedbackService _feedbackService;
        public FeedbackController(FeedbackService feedbackService)
        {
            //  _context = context;
            _feedbackService = feedbackService;
        }
        [HttpGet("{userId}")]
        public async Task<ActionResult<Feedback>> GetFeedbackByUserId(int userId)
        {

            var feedback = await _feedbackService.GetFeedbacksByUserId(userId);

            if (feedback == null)
            {
                return NotFound();
            }
            return feedback;


        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Course>>> GetAllFeedback()
        {
           
            var courses = await _feedbackService.GetAllFeedbacks();
            return Ok(courses);
        }


        [Authorize(Roles = "Educator")]

        [HttpPost]
        public async Task<ActionResult> AddFeedback([FromBody] Feedback feedback)
        {
            try
            {
                var success = await _feedbackService.AddFeedback(feedback);
                if (success)
                    return Ok(new { message = "Feedback added successfully" });
                else
                    return StatusCode(500, new { message = "Failed to add feedback" });
            }
            catch (Exception ex)
            {
                // Console.WriteLine("ex"+ex);
                return StatusCode(400, new { message = ex.Message });
            }
        }
              


    }
}
