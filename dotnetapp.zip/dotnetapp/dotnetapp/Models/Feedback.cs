﻿using System.ComponentModel.DataAnnotations;

namespace dotnetapp.Models
{
    public class Feedback
    {
        
        public int FeedbackId { get; set; }
        
        
        public int? UserId { get; set; }
        public User? User { get; set; }
        [Required]
        public DateTime Date { get; set; }
        [Required]
        public string? FeedbackGiven { get; set; }
      
    }
}
